package com.winterchen.utils;

import com.winterchen.model.UserDomain;
import com.winterchen.service.user.UserService;
import org.jsoup.Jsoup;

import java.io.IOException;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.springframework.beans.factory.annotation.Autowired;


public class Scrap {
    public static UserDomain getWuMaoW(){
        String url = "http://guba.eastmoney.com/type,zg80036742.html";
        Document doc = null;

        try {
            UserDomain userDomain = new UserDomain();
            doc = Jsoup.connect(url).get();
            Elements elements = doc.select(".pager").select("span");
            System.out.println(elements);
            Elements listDiv = doc.getElementsByAttributeValue("class", "articleh");
//            System.out.println(listDiv);

            for(Element element : listDiv){

                Elements texts = element.getElementsByTag("a");
                Elements texts1 = element.select(".l6");
                Elements texts2 = element.select(".l5");
                Elements texts3 = element.select(".l4");
                Elements texts4 = element.select(".l1");
                Elements texts5 = element.select(".l2");
//                System.out.println(texts1);
                for(Element text:texts4){
                    String ptext = text.text();
                    if(ptext!="") {
                        System.out.print("点击："+ptext+"	");
                    	userDomain.setClick(Integer.valueOf(ptext));
                    }

                }
                for(Element text:texts5){
                    String ptext = text.text();
                    if(ptext!="") {
                        System.out.print("点击："+ptext+"	");
                        userDomain.setReply(Integer.valueOf(ptext));
                    }

                }
                for(Element text:texts3){
                    String ptext = text.text();
                    if(ptext!="") {
                        userDomain.setAuthor(ptext);
                    }

                }
                for(Element text:texts2){
                    String ptext = text.text();
                    if(ptext!="") {
                        userDomain.setLastdata(ptext);
                    }

                }
                for(Element text:texts1){
                    String ptext = text.text();
                    if(ptext!="") {
                        userDomain.setSenddata(ptext);
                    }

                }
                for(Element text:texts){
                    String ptext = text.attr("title");
                    if(ptext!="") {
                        userDomain.setTitle(ptext);
                    }

                    return userDomain;


                }
            }
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return null;
    }
}
